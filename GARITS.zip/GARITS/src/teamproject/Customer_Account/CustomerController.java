package teamproject.Customer_Account;

import teamproject.Jobs.Task;
import java.util.Date;

public class CustomerController {

	/**
	 * 
	 * @param name
	 * @param emailAddress
	 * @param address
	 * @param postCode
	 * @param telephoneNumber
	 * @param fax
	 * @param dateCreated
	 */
    

}