package teamproject.Customer_Account;

public class FlexibleDiscount extends DiscountPlan {

	private double orderedValueThisMonth;
	private double applicableDiscount;
	private double valueToBeDeducted;

	/**
	 * 
	 * @param amount
	 */
	public void sendCheque(double amount) {
		// TODO - implement FlexibleDiscount.sendCheque
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param amount
	 */
	public void deductFromOrder(double amount) {
		// TODO - implement FlexibleDiscount.deductFromOrder
		throw new UnsupportedOperationException();
	}

	public double getOrderedValueThisMonth() {
		return this.orderedValueThisMonth;
	}

	public double getOrderedValueThisMonth2() {
		// TODO - implement FlexibleDiscount.getOrderedValueThisMonth2
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param orderedValueThisMonth
	 */
	public void setOrderedValueThisMonth(double orderedValueThisMonth) {
		this.orderedValueThisMonth = orderedValueThisMonth;
	}

	/**
	 * 
	 * @param orderedValueThisMonth
	 */
	public void setOrderedValueThisMonth2(double orderedValueThisMonth) {
		// TODO - implement FlexibleDiscount.setOrderedValueThisMonth2
		throw new UnsupportedOperationException();
	}

	public double getApplicableDiscount() {
		return this.applicableDiscount;
	}

	public double getApplicableDiscount2() {
		// TODO - implement FlexibleDiscount.getApplicableDiscount2
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param applicableDiscount
	 */
	public void setApplicableDiscount(double applicableDiscount) {
		this.applicableDiscount = applicableDiscount;
	}

	/**
	 * 
	 * @param applicableDiscount
	 */
	public void setApplicableDiscount2(double applicableDiscount) {
		// TODO - implement FlexibleDiscount.setApplicableDiscount2
		throw new UnsupportedOperationException();
	}

	public double getValueToBeDeducted() {
		return this.valueToBeDeducted;
	}

	public double getValueToBeDeducted2() {
		// TODO - implement FlexibleDiscount.getValueToBeDeducted2
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param valueToBeDeducted
	 */
	public void setValueToBeDeducted(double valueToBeDeducted) {
		this.valueToBeDeducted = valueToBeDeducted;
	}

	/**
	 * 
	 * @param valueToBeDeducted
	 */
	public void setValueToBeDeducted2(double valueToBeDeducted) {
		// TODO - implement FlexibleDiscount.setValueToBeDeducted2
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param orderedValueThisMonth
	 * @param applicableDiscount
	 * @param valueToBeDeducted
	 */
	public static FlexibleDiscount FlexibleDiscount(double orderedValueThisMonth, double applicableDiscount, double valueToBeDeducted) {
		// TODO - implement FlexibleDiscount.FlexibleDiscount
		throw new UnsupportedOperationException();
	}

}