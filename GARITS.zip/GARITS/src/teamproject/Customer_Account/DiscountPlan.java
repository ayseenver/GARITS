package teamproject.Customer_Account;

public abstract class DiscountPlan {

	public static DiscountPlan DiscountPlan() {
		// TODO - implement DiscountPlan.DiscountPlan
		throw new UnsupportedOperationException();
	}

}