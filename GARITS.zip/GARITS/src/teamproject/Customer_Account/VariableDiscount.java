package teamproject.Customer_Account;

public class VariableDiscount extends DiscountPlan {

	private float MoTPercentage;
	private float sparePartPercentage;
	private float servicePercentage;

	public float getMoTPercentage() {
		// TODO - implement VariableDiscount.getMoTPercentage
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param MoTPercentage
	 */
	public void setMoTPercentage(float MoTPercentage) {
		// TODO - implement VariableDiscount.setMoTPercentage
		throw new UnsupportedOperationException();
	}

	public float getSparePartPercentage() {
		return this.sparePartPercentage;
	}

	/**
	 * 
	 * @param sparePartsPercentage
	 */
	public void setSparePartPercentage(float sparePartsPercentage) {
		this.sparePartPercentage = sparePartsPercentage;
	}

	public float getServicePercentage() {
		return this.servicePercentage;
	}

	/**
	 * 
	 * @param servicePercentage
	 */
	public void setServicePercentage(float servicePercentage) {
		this.servicePercentage = servicePercentage;
	}

	/**
	 * 
	 * @param MoTPercentage
	 * @param sparePartPercentage
	 * @param servicePercentage
	 */
	public static VariableDiscount VariableDiscount(float MoTPercentage, float sparePartPercentage, float servicePercentage) {
		// TODO - implement VariableDiscount.VariableDiscount
		throw new UnsupportedOperationException();
	}

}