package teamproject.Reports;

import java.util.Date;
import teamproject.Reports.VehicleBookedIn;

public class ReportsController {

	/**
	 * 
	 * @param dateFrom
	 * @param dateTill
	 * @param reportDate
	 * @param content
	 */
	public StockLevel generateStockLevelReport(Date dateFrom, Date dateTill, Date reportDate, String content) {
		// TODO - implement ReportsController.generateStockLevelReport
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param dateFrom
	 * @param dateTill
	 * @param reportDate
	 * @param content
	 */
	public VehicleBookedIn generateVehicleBookedInlReport(Date dateFrom, Date dateTill, Date reportDate, String content) {
		// TODO - implement ReportsController.generateVehicleBookedInlReport
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param dateFrom
	 * @param dateTill
	 * @param reportDate
	 * @param content
	 */
	public AverageTimePrice generateAverageTimePriceReport(Date dateFrom, Date dateTill, Date reportDate, String content) {
		// TODO - implement ReportsController.generateAverageTimePriceReport
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param dateFrom
	 * @param dateTill
	 * @param reportDate
	 * @param content
	 */
	public AverageTimePrice generateAverageTimePrice(Date dateFrom, Date dateTill, Date reportDate, String content) {
		// TODO - implement ReportsController.generateAverageTimePrice
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param dateFrom
	 * @param dateTill
	 * @param reportDate
	 * @param content
	 * @param mechanic
	 */
	public AverageTimePrice generateAverageTimePriceByMechanic(Date dateFrom, Date dateTill, Date reportDate, String content, String mechanic) {
		// TODO - implement ReportsController.generateAverageTimePriceByMechanic
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param averageTimePrice
	 */
	public void printAverageTimePriceReport(AverageTimePrice averageTimePrice) {
		// TODO - implement ReportsController.printAverageTimePriceReport
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param stockLevel
	 */
	public void printStockLevelReport(StockLevel stockLevel) {
		// TODO - implement ReportsController.printStockLevelReport
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param stockLevel
	 */
	public void printVehicleBookedInReport(StockLevel stockLevel) {
		// TODO - implement ReportsController.printVehicleBookedInReport
		throw new UnsupportedOperationException();
	}

	public static ReportsController ReportsController() {
		// TODO - implement ReportsController.ReportsController
		throw new UnsupportedOperationException();
	}

}