package teamproject.Reports;

import java.util.Date;
import teamproject.Reports.Report;

public class StockLevel extends Report {

	public void generate() {
		// TODO - implement StockLevel.generate
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param dateFrom
	 * @param dateTill
	 * @param reportDate
	 * @param content
	 */
	public static StockLevel StockLevel(Date dateFrom, Date dateTill, Date reportDate, String content) {
		// TODO - implement StockLevel.StockLevel
		throw new UnsupportedOperationException();
	}

}