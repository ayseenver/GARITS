package teamproject.Reports;

import java.util.Date;
import teamproject.Reports.Report;

public class VehicleBookedIn extends Report {

	public void generate() {
		// TODO - implement VehicleBookedIn.generate
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param dateFrom
	 * @param dateTill
	 * @param reportDate
	 * @param content
	 */
	public static VehicleBookedIn VehicleBookedIn(Date dateFrom, Date dateTill, Date reportDate, String content) {
		// TODO - implement VehicleBookedIn.VehicleBookedIn
		throw new UnsupportedOperationException();
	}

}