package teamproject.Spare_Parts;

public class PartOrder {

	private String orderNumber;

	/**
	 * 
	 * @param details
	 */
	public void addPart(String[] details) {
		// TODO - implement PartOrder.addPart
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param partID
	 */
	public void removePart(int partID) {
		// TODO - implement PartOrder.removePart
		throw new UnsupportedOperationException();
	}

	public String[] retrieveOrderList() {
		// TODO - implement PartOrder.retrieveOrderList
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param orderNumber
	 */
	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	public String getOrderNumber() {
		return this.orderNumber;
	}

	public SparePart retrieveNextPart() {
		// TODO - implement PartOrder.retrieveNextPart
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param orderNumber
	 */
	public static PartOrder PartOrder(String orderNumber) {
		// TODO - implement PartOrder.PartOrder
		throw new UnsupportedOperationException();
	}

}