package Spare_Parts;

public class Vector {

	/**
	 * 
	 * @param details
	 */
	public void addPart(String[] details) {
		// TODO - implement Vector.addPart
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param id
	 */
	public void removePart(int id) {
		// TODO - implement Vector.removePart
		throw new UnsupportedOperationException();
	}

	public void next() {
		// TODO - implement Vector.next
		throw new UnsupportedOperationException();
	}

	public void go2top() {
		// TODO - implement Vector.go2top
		throw new UnsupportedOperationException();
	}

	private void append() {
		// TODO - implement Vector.append
		throw new UnsupportedOperationException();
	}

	public static Vector Vector() {
		// TODO - implement Vector.Vector
		throw new UnsupportedOperationException();
	}

}