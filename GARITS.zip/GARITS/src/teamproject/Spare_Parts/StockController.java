package teamproject.Spare_Parts;

import java.util.*;

public class StockController {

	Collection<PartOrder> creates;

	/**
	 * 
	 * @param orderNumber
	 */
	public PartOrder createPartOrder(String orderNumber) {
		// TODO - implement StockController.createPartOrder
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param orderNumber
	 */
	public void removePartOrder(String orderNumber) {
		// TODO - implement StockController.removePartOrder
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param orderNumber
	 */
	public PartOrder getPartOrder(String orderNumber) {
		// TODO - implement StockController.getPartOrder
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param orderNumber
	 * @param details
	 */
	public void addPartToOrder(String orderNumber, String[] details) {
		// TODO - implement StockController.addPartToOrder
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param orderNumber
	 * @param partID
	 */
	public void removePartFromPartOrder(String orderNumber, int partID) {
		// TODO - implement StockController.removePartFromPartOrder
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param orderNumber
	 */
	public SparePart[] getOrderPart(String orderNumber) {
		// TODO - implement StockController.getOrderPart
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param orderNumber
	 * @param isTop
	 */
	public SparePart getNextOrderPart(String orderNumber, boolean isTop) {
		// TODO - implement StockController.getNextOrderPart
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param partID
	 */
	public SparePart getPart(String partID) {
		// TODO - implement StockController.getPart
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param partID
	 * @param quantity
	 */
	public void updateStockLevel(String partID, int quantity) {
		// TODO - implement StockController.updateStockLevel
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param partID
	 */
	public Manufacturer getPartManufacturer(String partID) {
		// TODO - implement StockController.getPartManufacturer
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param partID
	 */
	public int getPartThreshold(String partID) {
		// TODO - implement StockController.getPartThreshold
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param partID
	 * @param threshold
	 */
	public void setPartThreshold(String partID, int threshold) {
		// TODO - implement StockController.setPartThreshold
		throw new UnsupportedOperationException();
	}

	public static StockController StockController() {
		// TODO - implement StockController.StockController
		throw new UnsupportedOperationException();
	}

}