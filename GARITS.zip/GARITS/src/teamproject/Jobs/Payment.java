package teamproject.Jobs;

public class Payment {

	private String paymentType;

	/**
	 * 
	 * @param invoiceNumber
	 */
	public Job makePayment(int invoiceNumber) {
		// TODO - implement Payment.makePayment
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param paymentType
	 */
	public static Payment Payment(String paymentType) {
		// TODO - implement Payment.Payment
		throw new UnsupportedOperationException();
	}

}