package teamproject.Jobs;

import teamproject.Spare_Parts.SparePart;

public class SparePartUsed {

	/**
	 * 
	 * @param sparePart
	 */
	public static SparePartUsed SparePartUsed(SparePart sparePart) {
		// TODO - implement SparePartUsed.SparePartUsed
		throw new UnsupportedOperationException();
	}

}