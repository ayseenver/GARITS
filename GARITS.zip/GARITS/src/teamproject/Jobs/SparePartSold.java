package teamproject.Jobs;

import teamproject.Spare_Parts.SparePart;

public class SparePartSold {

	/**
	 * 
	 * @param sparePart
	 */
	public static SparePartSold SparePartSold(SparePart sparePart) {
		// TODO - implement SparePartSold.SparePartSold
		throw new UnsupportedOperationException();
	}

}