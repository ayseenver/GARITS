package teamproject.Jobs;

import teamproject.Jobs.Task;

public class EstimatedTask {

	/**
	 * 
	 * @param task
	 */
	public static EstimatedTask EstimatedTask(Task task) {
		// TODO - implement EstimatedTask.EstimatedTask
		throw new UnsupportedOperationException();
	}

}