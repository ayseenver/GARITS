package teamproject.Jobs;

public class MoTInspectionBay {

	private int bayNumber;
	private boolean inUse;

	public int getBayNumber() {
		return this.bayNumber;
	}

	/**
	 * 
	 * @param bayNumber
	 */
	public void setBayNumber(int bayNumber) {
		this.bayNumber = bayNumber;
	}

	public boolean getInUse() {
		return this.inUse;
	}

	/**
	 * 
	 * @param inUse
	 */
	public void setInUse(boolean inUse) {
		this.inUse = inUse;
	}

	/**
	 * 
	 * @param bayNumber
	 * @param inUse
	 */
	public static MoTInspectionBay MoTInspectionBay(int bayNumber, boolean inUse) {
		// TODO - implement MoTInspectionBay.MoTInspectionBay
		throw new UnsupportedOperationException();
	}

}