package teamproject.Jobs;

import java.util.Date;

public class Invoice {

	private double VAT;
	private int invoiceNumber;
	private Date dateCreated;

	public Job calculate() {
		// TODO - implement Invoice.calculate
		throw new UnsupportedOperationException();
	}

	public double getVAT() {
		// TODO - implement Invoice.getVAT
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param VAT
	 */
	public void setVAT(double VAT) {
		// TODO - implement Invoice.setVAT
		throw new UnsupportedOperationException();
	}

	public int getInvoiceNumber() {
		return this.invoiceNumber;
	}

	/**
	 * 
	 * @param invoiceNumber
	 */
	public void setInvoiceNumber(int invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public Date getCreatedDate() {
		// TODO - implement Invoice.getCreatedDate
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param date
	 */
	public void setCreatedDate(Date date) {
		// TODO - implement Invoice.setCreatedDate
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param VAT
	 * @param invoiceNumber
	 * @param dateCreated
	 */
	public static Invoice Invoice(double VAT, int invoiceNumber, Date dateCreated) {
		// TODO - implement Invoice.Invoice
		throw new UnsupportedOperationException();
	}

}