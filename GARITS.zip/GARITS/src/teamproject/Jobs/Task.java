package teamproject.Jobs;

public class Task {

	private int taskID;
	private String description;
	private double estimatedHour;
	private double estimatedCost;

	public int getTaskID() {
		return this.taskID;
	}

	/**
	 * 
	 * @param taskID
	 */
	public void setTaskID(int taskID) {
		this.taskID = taskID;
	}

	public String getDescriptions() {
		// TODO - implement Task.getDescriptions
		throw new UnsupportedOperationException();
	}

	public double getHours() {
		// TODO - implement Task.getHours
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param Hours
	 */
	public void setHours(double Hours) {
		// TODO - implement Task.setHours
		throw new UnsupportedOperationException();
	}

	public double getCost() {
		// TODO - implement Task.getCost
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param Cost
	 */
	public void setCost(double Cost) {
		// TODO - implement Task.setCost
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param taskID
	 * @param description
	 * @param estimatedHour
	 * @param estimatedCost
	 */
	public static Task Task(int taskID, String description, double estimatedHour, double estimatedCost) {
		// TODO - implement Task.Task
		throw new UnsupportedOperationException();
	}

}