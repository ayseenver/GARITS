package teamproject.AlertsReminders;

import java.util.*;

public class ReminderController {

	Collection<Reminder> creates;

	public void printAllReminders() {
		// TODO - implement ReminderController.printAllReminders
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param type
	 */
	public void printSpecificTypeReminder(String type) {
		// TODO - implement ReminderController.printSpecificTypeReminder
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param reminder
	 */
	public void printIndividualReminder(Reminder reminder) {
		// TODO - implement ReminderController.printIndividualReminder
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param date
	 * @param type
	 * @param description
	 */
	public Reminder createReminder(Date date, String type, String description) {
		// TODO - implement ReminderController.createReminder
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param reminder
	 */
	public void removeReminder(Reminder reminder) {
		// TODO - implement ReminderController.removeReminder
		throw new UnsupportedOperationException();
	}

	public static ReminderController ReminderController() {
		// TODO - implement ReminderController.ReminderController
		throw new UnsupportedOperationException();
	}

}