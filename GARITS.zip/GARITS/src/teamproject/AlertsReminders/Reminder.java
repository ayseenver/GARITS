package teamproject.AlertsReminders;

import java.util.Date;

public class Reminder {

	private Date date;
	private String type;
	private String description;

	/**
	 * 
	 * @param date
	 */
	public void setDate(Date date) {
		//TODO - implement Reminder.setDate
		throw new UnsupportedOperationException();
	}

	public String getType() {
		// TODO - implement Reminder.getType
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param type
	 */
	public void setType(String type) {
		// TODO - implement Reminder.setType
		throw new UnsupportedOperationException();
	}

	public String getDescription() {
		// TODO - implement Reminder.getDescription
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param description
	 */
	public void setDescription1(String description) {
		// TODO - implement Reminder.setDescription
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param date
	 * @param type
	 * @param description
	 */
	public static Reminder Reminder(Date date, String type, String description) {
		// TODO - implement Reminder.Reminder
		throw new UnsupportedOperationException();
	}

}