package teamproject.User_Accounts;

public class UserAccountsController {

	/**
	 * 
	 * @param username
	 * @param firstName
	 * @param lastName
	 * @param password
	 * @param roleID
	 */
	public User createUser(String username, String firstName, String lastName, String password, int roleID) {
		// TODO - implement UserAccountsController.createUser
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param username
	 */
	public User getUser(String username) {
		// TODO - implement UserAccountsController.getUser
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param username
	 */
	public void removeUser(String username) {
		// TODO - implement UserAccountsController.removeUser
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param username
	 * @param password
	 */
	public void login(String username, String password) {
		// TODO - implement UserAccountsController.login
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param username
	 */
	public void logout(String username) {
		// TODO - implement UserAccountsController.logout
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param username
	 * @param firstName
	 */
	public void setFirstName(String username, String firstName) {
		// TODO - implement UserAccountsController.setFirstName
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param username
	 * @param lastName
	 */
	public void setLastName(String username, String lastName) {
		// TODO - implement UserAccountsController.setLastName
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param username
	 * @param password
	 */
	public void setPassword(String username, String password) {
		// TODO - implement UserAccountsController.setPassword
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param username
	 * @param roleName
	 */
	public void setRoleName(String username, String roleName) {
		// TODO - implement UserAccountsController.setRoleName
		throw new UnsupportedOperationException();
	}

	public static UserAccountsController UserAccountsController() {
		// TODO - implement UserAccountsController.UserAccountsController
		throw new UnsupportedOperationException();
	}

}